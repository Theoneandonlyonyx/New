package com.mikexxx.a71opt.client;

import com.mikexxx.a71opt.A71Optimizer;

import java.lang.reflect.Method;

/**
 * Schaltet Shader ueber die Iris-API von Oculus, ohne dass Oculus beim Bauen noetig ist (Reflection).
 * Ist die API nicht auffindbar, passiert nichts und alle Methoden melden "nicht moeglich".
 */
final class ShaderControl {

    private static boolean tried = false;
    private static boolean available = false;
    private static Object config;
    private static Method areEnabled;
    private static Method setEnabledAndApply;

    private ShaderControl() {
    }

    private static Class<?> load(String name) throws ClassNotFoundException {
        try {
            return Class.forName(name);
        } catch (ClassNotFoundException first) {
            ClassLoader loader = Thread.currentThread().getContextClassLoader();
            if (loader == null) {
                throw first;
            }
            return Class.forName(name, true, loader);
        }
    }

    private static boolean init() {
        if (tried) {
            return available;
        }
        tried = true;
        try {
            Class<?> api = load("net.irisshaders.iris.api.v0.IrisApi");
            Class<?> configType = load("net.irisshaders.iris.api.v0.IrisApiConfig");
            Object instance = api.getMethod("getInstance").invoke(null);
            config = api.getMethod("getConfig").invoke(instance);
            areEnabled = configType.getMethod("areShadersEnabled");
            setEnabledAndApply = configType.getMethod("setShadersEnabledAndApply", boolean.class);
            available = config != null;
        } catch (Throwable t) {
            available = false;
            A71Optimizer.LOGGER.info("[A71] Shader-Schalter nicht verfuegbar (Oculus/Iris-API nicht gefunden): {}", t.toString());
        }
        return available;
    }

    static boolean isEnabled() {
        try {
            return init() && Boolean.TRUE.equals(areEnabled.invoke(config));
        } catch (Throwable t) {
            return false;
        }
    }

    /** @return true, wenn der Schalter ausgefuehrt wurde */
    static boolean setEnabled(boolean on) {
        try {
            if (!init()) {
                return false;
            }
            setEnabledAndApply.invoke(config, on);
            return true;
        } catch (Throwable t) {
            A71Optimizer.LOGGER.warn("[A71] Shader konnten nicht umgeschaltet werden", t);
            return false;
        }
    }

    /** Kurztext fuer Log und HUD: an / aus / - (nicht verfuegbar) */
    static String state() {
        if (!init()) {
            return "-";
        }
        return isEnabled() ? "an" : "aus";
    }
}
