package com.mikexxx.a71opt.client;

import com.mikexxx.a71opt.A71Config;
import com.mikexxx.a71opt.A71Optimizer;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.util.Locale;

/**
 * Misst FPS (Client) und Tickzeit (integrierter Server) und passt die Renderdistanz sanft an.
 *
 * Wichtig: Embeddium baut bei jeder Aenderung der Renderdistanz den Chunk-Renderer neu auf.
 * Darum gibt es lange Beruhigungszeiten, wenige Schritte und ein "gelerntes" Maximum,
 * damit es nicht hin- und herspringt.
 */
@Mod.EventBusSubscriber(modid = A71Optimizer.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class Governor {

    static final String GREEN = "\u00a7a";
    static final String YELLOW = "\u00a7e";
    static final String GRAY = "\u00a77";
    static final String RESET = "\u00a7r";

    private static final long WINDOW_NS = 2_000_000_000L;
    private static final long SETTLE_MS = 6_000L;
    private static final long HOLD_AFTER_LOWER_MS = 60_000L;
    private static final long LEARN_MS = 60_000L;
    private static final long FORGET_LEARNED_MS = 600_000L;
    private static final long EMERGENCY_GRACE_MS = 25_000L;
    private static final int BLACKBOX_EVERY_WINDOWS = 3;

    // Messwerte
    private static volatile double serverTickMs = 0.0D;
    private static volatile double serverTickMaxMs = 0.0D;
    private static long serverTickStartNs = 0L;
    private static int windowFrames = 0;
    private static long windowStartNs = 0L;
    private static double fps = 0.0D;

    // Zustand
    private static boolean startupDone = false;
    private static boolean wasInWorld = false;
    private static boolean firstJoinDone = false;
    private static boolean auto = true;
    private static boolean hud = true;
    private static int targetFps = 24;
    private static int userRd = -1;
    private static int ceiling = 6;
    private static int learnedCeiling = -1;
    private static long learnedAtMs = 0L;
    private static int lastSetRd = -1;
    private static int goodWindows = 0;
    private static int badWindows = 0;
    private static boolean ramping = false;
    private static boolean lowFpsHintShown = false;
    private static long lastChangeMs = 0L;
    private static long lastRaiseMs = 0L;
    private static long lastLowerMs = 0L;
    private static int changes = 0;
    private static int errors = 0;
    private static int hudTicker = 0;
    private static long joinedAtMs = 0L;
    private static int panicWindows = 0;
    private static int calmWindows = 0;
    private static boolean emergencyActive = false;
    private static int emergencies = 0;
    private static int bbCounter = 0;
    private static long gcCountPrev = -1L;
    private static long gcMsPrev = -1L;
    private static long bbGcCount = 0L;
    private static long bbGcMs = 0L;
    private static double lastGcShare = 0.0D;
    private static double lastWindowSec = 2.0D;
    private static String hudText = "";
    private static int hudColor = 0xFFFFFF;

    private Governor() {
    }

    // ------------------------------------------------------------------ Ereignisse

    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase == TickEvent.Phase.START) {
            windowFrames++;
        }
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.START) {
            serverTickStartNs = System.nanoTime();
        } else if (serverTickStartNs != 0L) {
            double ms = (System.nanoTime() - serverTickStartNs) / 1.0e6D;
            serverTickMs = serverTickMs * 0.95D + ms * 0.05D;
            if (ms > serverTickMaxMs) {
                serverTickMaxMs = ms;
            }
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || errors > 5) {
            return;
        }
        try {
            tick(Minecraft.getInstance());
        } catch (Throwable t) {
            errors++;
            A71Optimizer.LOGGER.error("[A71] Fehler im Controller (Nr. {}), nach 6 Fehlern wird er abgeschaltet", errors, t);
        }
    }

    @SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Post event) {
        if (!hud || hudText.isEmpty()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui || mc.options.renderDebug) {
            return;
        }
        event.getGuiGraphics().drawString(mc.font, hudText, 4, 4, hudColor);
    }

    // ------------------------------------------------------------------ Ablauf

    private static void tick(Minecraft mc) {
        if (!A71Config.ENABLED.get()) {
            return;
        }
        if (!startupDone) {
            if (mc.getOverlay() != null) {
                return;
            }
            startup(mc);
            return;
        }

        boolean inWorld = mc.level != null && mc.player != null;
        if (inWorld != wasInWorld) {
            wasInWorld = inWorld;
            if (inWorld) {
                onJoin(mc);
            } else {
                onLeave(mc);
            }
        }
        if (!inWorld) {
            return;
        }

        long now = System.nanoTime();
        if (mc.isPaused() || windowStartNs == 0L) {
            windowStartNs = now;
            windowFrames = 0;
            return;
        }

        hudTicker++;
        if (hud && hudTicker >= 10) {
            hudTicker = 0;
            refreshHud(mc);
        }

        if (now - windowStartNs < WINDOW_NS) {
            return;
        }
        lastWindowSec = (now - windowStartNs) / 1.0e9D;
        fps = windowFrames / lastWindowSec;
        windowStartNs = now;
        windowFrames = 0;
        sampleGc();
        blackBox(mc);
        if (A71Config.EMERGENCY.get() && emergency(mc)) {
            return;
        }
        if (auto) {
            evaluate(mc);
        }
    }

    private static void startup(Minecraft mc) {
        startupDone = true;
        hud = A71Config.SHOW_HUD.get();
        auto = A71Config.ADAPTIVE.get();
        targetFps = A71Config.TARGET_FPS.get();
        Report.writeFile();
        if (A71Config.APPLY_PROFILE.get() && !Profile.wasApplied()) {
            Profile.apply(mc);
            Profile.markApplied();
        }
    }

    private static void onJoin(Minecraft mc) {
        resetBaseline(mc);
        joinedAtMs = System.currentTimeMillis();
        panicWindows = 0;
        calmWindows = 0;
        emergencyActive = false;
        gcCountPrev = -1L;
        bbCounter = 0;
        long nowMs = System.currentTimeMillis();
        if (auto) {
            int min = A71Config.MIN_RENDER_DISTANCE.get();
            int start = Math.min(ceiling, Math.max(min, A71Config.JOIN_RENDER_DISTANCE.get()));
            if (start < mc.options.renderDistance().get()) {
                ramping = true;
                applyRd(mc, start, nowMs);
                changes = 0;
            }
        }
        serverTickMs = 0.0D;
        if (!firstJoinDone) {
            firstJoinDone = true;
            Report.firstJoinHints(mc);
        }
    }

    private static void onLeave(Minecraft mc) {
        if (lastSetRd >= 0 && userRd > 0 && lastSetRd != userRd
                && mc.options.renderDistance().get() == lastSetRd) {
            // Wunschwert zurueck, damit options.txt nicht dauerhaft die gesenkte Distanz speichert
            mc.options.renderDistance().set(userRd);
        }
        lastSetRd = -1;
        ramping = false;
        goodWindows = 0;
        badWindows = 0;
        windowStartNs = 0L;
        windowFrames = 0;
        hudText = "";
    }

    /** Aktuelle Renderdistanz als Wunschwert des Spielers uebernehmen. */
    private static void resetBaseline(Minecraft mc) {
        int min = A71Config.MIN_RENDER_DISTANCE.get();
        int max = Math.max(min, A71Config.MAX_RENDER_DISTANCE.get());
        int cur = mc.options.renderDistance().get();
        userRd = cur;
        ceiling = clamp(cur, min, max);
        learnedCeiling = -1;
        lastSetRd = cur;
        ramping = false;
        lowFpsHintShown = false;
        goodWindows = 0;
        badWindows = 0;
        changes = 0;
        lastRaiseMs = 0L;
        lastLowerMs = 0L;
        lastChangeMs = System.currentTimeMillis();
        windowStartNs = System.nanoTime();
        windowFrames = 0;
    }

    private static void evaluate(Minecraft mc) {
        long nowMs = System.currentTimeMillis();
        int min = A71Config.MIN_RENDER_DISTANCE.get();
        int max = Math.max(min, A71Config.MAX_RENDER_DISTANCE.get());
        int cur = mc.options.renderDistance().get();

        if (lastSetRd >= 0 && cur != lastSetRd) {
            // Der Spieler hat selbst an der Renderdistanz gedreht: das ist der neue Wunschwert.
            userRd = cur;
            ceiling = clamp(cur, min, max);
            lastSetRd = cur;
            learnedCeiling = -1;
            ramping = false;
            goodWindows = 0;
            badWindows = 0;
            lastChangeMs = nowMs;
            return;
        }
        if (nowMs - lastChangeMs < SETTLE_MS) {
            goodWindows = 0;
            badWindows = 0;
            return;
        }
        if (learnedCeiling > 0 && nowMs - learnedAtMs > FORGET_LEARNED_MS) {
            learnedCeiling = -1;
        }

        double serverMs = serverTickMs;
        boolean bad = fps < targetFps * 0.75D || serverMs > 45.0D;
        boolean good = !bad && fps > targetFps * 1.1D && serverMs < 35.0D;
        if (bad) {
            badWindows++;
            goodWindows = 0;
        } else if (good) {
            goodWindows++;
            badWindows = 0;
        } else {
            badWindows = 0;
        }

        if (cur <= min && fps < 12.0D && badWindows >= 5 && !lowFpsHintShown) {
            lowFpsHintShown = true;
            msg(mc, YELLOW + "[A71]" + RESET + " Sehr niedrige FPS schon bei kleinster Renderdistanz."
                    + " Im Shader-Menue Schatten/Qualitaet senken oder Shader testweise aus.");
        }

        int eff = effectiveCeiling(min);
        if (badWindows >= 3 && cur > min) {
            int next = cur - 1;
            if (lastRaiseMs > 0L && nowMs - lastRaiseMs < LEARN_MS) {
                learnedCeiling = next;
                learnedAtMs = nowMs;
            }
            applyRd(mc, next, nowMs);
            lastLowerMs = nowMs;
            ramping = false;
            return;
        }

        int need = ramping ? 3 : 10;
        boolean holdOver = nowMs - lastLowerMs >= HOLD_AFTER_LOWER_MS;
        if (goodWindows >= need && cur < eff && (ramping || holdOver)) {
            applyRd(mc, cur + 1, nowMs);
            lastRaiseMs = nowMs;
            if (cur + 1 >= eff) {
                ramping = false;
            }
        }
    }

    private static int effectiveCeiling(int min) {
        int eff = ceiling;
        if (learnedCeiling > 0) {
            eff = Math.min(eff, learnedCeiling);
        }
        return Math.max(min, eff);
    }

    private static void applyRd(Minecraft mc, int value, long nowMs) {
        int before = mc.options.renderDistance().get();
        mc.options.renderDistance().set(value);
        lastSetRd = mc.options.renderDistance().get();
        lastChangeMs = nowMs;
        goodWindows = 0;
        badWindows = 0;
        changes++;
        A71Optimizer.LOGGER.info("[A71] Renderdistanz {} -> {} (FPS {}, Server {} ms, Ziel {})",
                before, lastSetRd, Math.round(fps), Math.round(serverTickMs), targetFps);
    }

    private static int clamp(int value, int lo, int hi) {
        return Math.max(lo, Math.min(hi, value));
    }

    private static void refreshHud(Minecraft mc) {
        int min = A71Config.MIN_RENDER_DISTANCE.get();
        Runtime rt = Runtime.getRuntime();
        long usedMb = (rt.totalMemory() - rt.freeMemory()) / 1048576L;
        long maxMb = rt.maxMemory() / 1048576L;
        hudText = String.format(Locale.ROOT, "A71 %d FPS | Server %.0f ms | RD %d/%d%s | RAM %d/%d MB | GC %.0f%%",
                Math.round(fps), serverTickMs, mc.options.renderDistance().get(), effectiveCeiling(min),
                auto ? " auto" : "", usedMb, maxMb, lastGcShare * 100.0D);
        if (fps >= targetFps * 0.9D) {
            hudColor = 0x55FF55;
        } else if (fps >= targetFps * 0.6D) {
            hudColor = 0xFFFF55;
        } else {
            hudColor = 0xFF5555;
        }
    }

    // ------------------------------------------------------------------ Messung, Flugschreiber, Notbremse

    /** Zeit, die die Garbage Collection im letzten Fenster gebraucht hat (Anteil 0..1). */
    private static void sampleGc() {
        try {
            long count = 0L;
            long ms = 0L;
            for (GarbageCollectorMXBean bean : ManagementFactory.getGarbageCollectorMXBeans()) {
                long c = bean.getCollectionCount();
                long t = bean.getCollectionTime();
                if (c > 0L) {
                    count += c;
                }
                if (t > 0L) {
                    ms += t;
                }
            }
            if (gcCountPrev >= 0L) {
                long dCount = count - gcCountPrev;
                long dMs = ms - gcMsPrev;
                bbGcCount += dCount;
                bbGcMs += dMs;
                lastGcShare = Math.max(0.0D, Math.min(1.0D, dMs / (lastWindowSec * 1000.0D)));
            }
            gcCountPrev = count;
            gcMsPrev = ms;
        } catch (Throwable t) {
            lastGcShare = 0.0D;
        }
    }

    /** Eine Zeile alle ca. 6 Sekunden in latest.log, Stichwort [A71-BB]. Hilft bei der Fehlersuche nach einem Freeze. */
    private static void blackBox(Minecraft mc) {
        bbCounter++;
        if (bbCounter < BLACKBOX_EVERY_WINDOWS) {
            return;
        }
        bbCounter = 0;
        Runtime rt = Runtime.getRuntime();
        long usedMb = (rt.totalMemory() - rt.freeMemory()) / 1048576L;
        long maxMb = rt.maxMemory() / 1048576L;
        long sinceJoin = (System.currentTimeMillis() - joinedAtMs) / 1000L;
        double share = Math.min(100.0D, bbGcMs / (BLACKBOX_EVERY_WINDOWS * lastWindowSec * 10.0D));
        A71Optimizer.LOGGER.info(String.format(Locale.ROOT,
                "[A71-BB] +%ds fps=%.0f server=%.0f/%.0fms heap=%d/%dMB gc=%dx %dms (%.0f%%) cpu=%d rd=%d shader=%s%s",
                sinceJoin, fps, serverTickMs, serverTickMaxMs, usedMb, maxMb, bbGcCount, bbGcMs, share,
                rt.availableProcessors(), mc.options.renderDistance().get(), ShaderControl.state(),
                emergencyActive ? " NOTBREMSE" : ""));
        serverTickMaxMs = 0.0D;
        bbGcCount = 0L;
        bbGcMs = 0L;
    }

    /**
     * Notbremse: greift nach ca. 6 Sekunden Dauer-Freeze (zu wenig FPS, Speicher-Aufraeumen frisst die Zeit
     * oder Heap fast voll) sofort hart durch: Renderdistanz auf das Minimum und Shader aus.
     * Erst wenn es 10 Sekunden ruhig war, kann sie erneut ausloesen.
     *
     * @return true, wenn sie in diesem Fenster ausgeloest hat
     */
    private static boolean emergency(Minecraft mc) {
        long nowMs = System.currentTimeMillis();
        if (nowMs - joinedAtMs < EMERGENCY_GRACE_MS) {
            return false;
        }
        Runtime rt = Runtime.getRuntime();
        double heapPct = (rt.totalMemory() - rt.freeMemory()) * 100.0D / rt.maxMemory();
        boolean slow = fps < A71Config.EMERGENCY_FPS.get();
        boolean gcThrash = lastGcShare > 0.35D;
        boolean heapFull = heapPct > 95.0D;

        if (slow || gcThrash || heapFull) {
            panicWindows++;
            calmWindows = 0;
        } else {
            panicWindows = 0;
            calmWindows++;
            if (calmWindows >= 5) {
                emergencyActive = false;
            }
        }
        if (emergencyActive || panicWindows < 3) {
            return false;
        }

        emergencyActive = true;
        emergencies++;
        panicWindows = 0;

        int min = A71Config.MIN_RENDER_DISTANCE.get();
        int target = A71Config.EMERGENCY_RENDER_DISTANCE.get();
        int before = mc.options.renderDistance().get();
        if (before > target) {
            learnedCeiling = Math.max(min, before - 1);
            learnedAtMs = nowMs;
            applyRd(mc, target, nowMs);
        }
        lastLowerMs = nowMs;
        ramping = false;

        boolean shadersOff = false;
        if (A71Config.EMERGENCY_SHADERS_OFF.get() && ShaderControl.isEnabled()) {
            shadersOff = ShaderControl.setEnabled(false);
        }

        String why;
        if (slow) {
            why = "nur " + Math.round(fps) + " FPS";
        } else if (gcThrash) {
            why = "Speicher-Aufraeumen frisst " + Math.round(lastGcShare * 100.0D) + " % der Zeit";
        } else {
            why = "Heap fast voll (" + Math.round(heapPct) + " %)";
        }
        msg(mc, YELLOW + "[A71] Notbremse:" + RESET + " " + why + ". Renderdistanz " + before + " -> "
                + mc.options.renderDistance().get() + (shadersOff ? ", Shader aus (wieder an: /a71 shader on)" : "") + ".");
        return true;
    }

    // ------------------------------------------------------------------ Befehle (von ClientCommands)

    static void msg(Minecraft mc, String text) {
        if (mc.player != null) {
            mc.player.displayClientMessage(Component.literal(text), false);
        }
        A71Optimizer.LOGGER.info("[A71] {}", text.replaceAll("\u00a7.", ""));
    }

    static void status(Minecraft mc) {
        int min = A71Config.MIN_RENDER_DISTANCE.get();
        Runtime rt = Runtime.getRuntime();
        long usedMb = (rt.totalMemory() - rt.freeMemory()) / 1048576L;
        long maxMb = rt.maxMemory() / 1048576L;
        msg(mc, String.format(Locale.ROOT, GREEN + "[A71]" + RESET + " FPS %.0f (Ziel %d) | Server %.0f ms pro Tick",
                fps, targetFps, serverTickMs));
        msg(mc, String.format(Locale.ROOT, " RD jetzt %d | Wunsch %d | gelernt max %s | min %d | Auto %s | Anpassungen %d",
                mc.options.renderDistance().get(), ceiling,
                learnedCeiling > 0 ? String.valueOf(learnedCeiling) : "-", min, auto ? "an" : "aus", changes));
        msg(mc, String.format(Locale.ROOT, " RAM %d / %d MB | GC-Anteil %.0f%% | Notbremsen %d | Shader %s",
                usedMb, maxMb, lastGcShare * 100.0D, emergencies, ShaderControl.state()));
    }

    static void toggleHud(Minecraft mc) {
        hud = !hud;
        if (hud) {
            refreshHud(mc);
        }
        msg(mc, GRAY + "[A71] HUD " + (hud ? "an" : "aus")
                + " (dauerhaft in config/mikexxx_a71opt-client.toml)");
    }

    static void toggleAuto(Minecraft mc) {
        auto = !auto;
        if (mc.level != null) {
            if (auto) {
                resetBaseline(mc);
            } else if (userRd > 0 && mc.options.renderDistance().get() != userRd) {
                applyRd(mc, userRd, System.currentTimeMillis());
            }
        }
        msg(mc, GRAY + "[A71] Auto-Renderdistanz " + (auto ? "an" : "aus"
                + " (Renderdistanz wieder auf deinem Wunschwert)"));
    }

    static void setRenderDistance(Minecraft mc, int value) {
        int min = A71Config.MIN_RENDER_DISTANCE.get();
        userRd = value;
        ceiling = Math.max(min, value);
        learnedCeiling = -1;
        ramping = false;
        applyRd(mc, value, System.currentTimeMillis());
        msg(mc, GRAY + "[A71] Renderdistanz " + value
                + (auto ? " (Wunschwert; die Automatik darf bei Lag trotzdem senken, /a71 auto schaltet sie aus)" : ""));
    }

    static void setTarget(Minecraft mc, int value) {
        targetFps = value;
        msg(mc, GRAY + "[A71] Ziel-FPS " + value + " (dauerhaft: zielFps in der Config)");
    }

    static void setShaders(Minecraft mc, boolean on) {
        if (ShaderControl.setEnabled(on)) {
            msg(mc, GRAY + "[A71] Shader " + (on ? "an" : "aus"));
        } else {
            msg(mc, YELLOW + "[A71]" + RESET
                    + " Shader-Schalter nicht moeglich (Oculus-API nicht gefunden). Im Shader-Menue umschalten.");
        }
    }

    static void reapplyProfile(Minecraft mc) {
        Profile.apply(mc);
        Profile.markApplied();
        if (mc.level != null) {
            resetBaseline(mc);
        }
        msg(mc, GREEN + "[A71]" + RESET + " A71-Profil angewendet.");
    }
}
