package com.mikexxx.a71opt.client;

import com.mikexxx.a71opt.A71Optimizer;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterClientCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * /a71 status | hud | auto | rd <n> | ziel <fps> | profil | report | spawn | shader on/off
 * Reine Client-Befehle, laufen auch ohne Cheats und in jeder Welt.
 */
@Mod.EventBusSubscriber(modid = A71Optimizer.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientCommands {

    private ClientCommands() {
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterClientCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();

        dispatcher.register(Commands.literal("a71")
                .executes(ctx -> {
                    Governor.status(Minecraft.getInstance());
                    return 1;
                })
                .then(Commands.literal("status").executes(ctx -> {
                    Governor.status(Minecraft.getInstance());
                    return 1;
                }))
                .then(Commands.literal("hud").executes(ctx -> {
                    Governor.toggleHud(Minecraft.getInstance());
                    return 1;
                }))
                .then(Commands.literal("auto").executes(ctx -> {
                    Governor.toggleAuto(Minecraft.getInstance());
                    return 1;
                }))
                .then(Commands.literal("profil").executes(ctx -> {
                    Governor.reapplyProfile(Minecraft.getInstance());
                    return 1;
                }))
                .then(Commands.literal("report").executes(ctx -> {
                    Report.chatSummary(Minecraft.getInstance());
                    return 1;
                }))
                .then(Commands.literal("spawn").executes(ctx -> {
                    Minecraft mc = Minecraft.getInstance();
                    MinecraftServer server = mc.getSingleplayerServer();
                    if (server == null) {
                        Governor.msg(mc, Governor.YELLOW + "[A71]" + Governor.RESET
                                + " Spawn-Chunks gibt es nur in Einzelspieler-Welten.");
                    } else {
                        server.execute(() -> SpawnChunks.shrink(server));
                        Governor.msg(mc, Governor.GRAY + "[A71] Spawn-Chunks werden verkleinert (Radius laut Config).");
                    }
                    return 1;
                }))
                .then(Commands.literal("shader")
                        .then(Commands.literal("on").executes(ctx -> {
                            Governor.setShaders(Minecraft.getInstance(), true);
                            return 1;
                        }))
                        .then(Commands.literal("off").executes(ctx -> {
                            Governor.setShaders(Minecraft.getInstance(), false);
                            return 1;
                        })))
                .then(Commands.literal("rd")
                        .then(Commands.argument("n", IntegerArgumentType.integer(2, 32))
                                .executes(ctx -> {
                                    Governor.setRenderDistance(Minecraft.getInstance(), IntegerArgumentType.getInteger(ctx, "n"));
                                    return 1;
                                })))
                .then(Commands.literal("ziel")
                        .then(Commands.argument("fps", IntegerArgumentType.integer(10, 120))
                                .executes(ctx -> {
                                    Governor.setTarget(Minecraft.getInstance(), IntegerArgumentType.getInteger(ctx, "fps"));
                                    return 1;
                                }))));
    }
}
