# Mikexxx A71 Optimizer (Forge 1.20.1)

Client-Mod fuer Minecraft Java auf dem Samsung A71 (MJLauncher, Renderer LTW, Shader).

## Bauen
1. Alles aus dieser ZIP in ein GitHub-Repository hochladen (Ordner `mod/` und `.github/` im Hauptverzeichnis).
2. Reiter "Actions" -> Workflow "build-jar" laeuft automatisch (oder "Run workflow").
3. Unten beim fertigen Lauf unter "Artifacts" `mikexxx_a71opt-jar` laden, entpacken.
4. Alte jar (1.0.0) aus dem `mods`-Ordner loeschen, sonst gibt es einen Duplikat-Fehler.
5. Die Datei `mikexxx_a71opt-1.1.0.jar` in den `mods`-Ordner der Instanz legen.

## Was die Mod macht
- **A71-Profil** (einmalig beim ersten Start): Renderdistanz 5, Simulationsdistanz 5, 60 FPS-Limit, Grafik "Schnell",
  weniger Partikel, Wolken aus, Entity-Schatten aus, kurze Entity-Sichtweite, Biom-Uebergang 1.
- **Spawn-Chunks verkleinern**: Vanilla haelt um den Welt-Spawn dauerhaft einen riesigen Bereich geladen. Das wird
  nach dem Start auf Radius 2 gesenkt (weniger RAM, weniger Tick-Last, viel kuerzeres Speichern).
- **Adaptive Renderdistanz**: startet beim Betreten einer Welt klein und faehrt schrittweise hoch, senkt bei
  Lag (FPS unter 75 % vom Ziel oder Server-Tick ueber 45 ms) und lernt eine Obergrenze.
- **Notbremse** (neu in 1.1.0): Bei Dauer-Freeze (unter 6 FPS, Speicher-Aufraeumen frisst ueber 35 % der Zeit oder Heap
  ueber 95 %) springt die Renderdistanz sofort auf 2 und die Shader gehen aus. Wieder an: `/a71 shader on`.
- **Flugschreiber** (neu in 1.1.0): alle ca. 6 Sekunden eine Zeile `[A71-BB]` in latest.log (FPS, Server-Tick, Heap,
  GC-Zeit, CPU-Kerne, Renderdistanz, Shader). Damit laesst sich nach einem Freeze die Ursache finden.
- **HUD** oben links: FPS, Server-Tickzeit, Renderdistanz, RAM, GC-Anteil.
- **Bericht** `config/mikexxx_a71opt-bericht.txt`: Heap, Geraete-RAM, Kerne, Grafik, Mod-Hinweise.

## Befehle (im Chat)
`/a71 status`, `/a71 hud`, `/a71 auto`, `/a71 rd <n>`, `/a71 ziel <fps>`, `/a71 profil`, `/a71 report`, `/a71 spawn`, `/a71 shader on|off`

## Einstellungen
`config/mikexxx_a71opt-client.toml` (Ziel-FPS, Renderdistanz-Grenzen, Profilwerte, Spawn-Radius, HUD an/aus).
